# ML-Iris-dataset
First machine learning project following a tutorial, it used the Iris dataset.
